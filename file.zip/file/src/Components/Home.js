function Home () {
    return (
        <div>
            <div style={{
                position:"relative",
            }}>
                <img style={{
                    width:"100%",
                    height:"700px",
                }} src="https://cdn.dribbble.com/users/1464189/screenshots/10478957/media/3d47a4156058d329c10efc45d00579bd.jpg" alt="react-redux"/>
                <p style={{
                    position:"absolute",
                    top:"40px",
                    left:"40%",
                    fontSize:"50px",
                    color:"greenyellow",
                    fontFamily:"Arial"
                }}>React Redux</p>
            </div>
        </div>
    )
};
export default Home;